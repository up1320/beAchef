const express = require("express")
const App = express()
var PORT = process.env.PORT || 3000


App.set("views",__dirname + "/views")
App.set("view engine","ejs")
App.use(express.static(__dirname + "/public"))
App.get("/",(req,res)=>{
    res.render("landing.ejs")
})

App.get("/recipes",(req,res)=>{
    res.render("home.ejs")
})

App.get("/login",(req,res)=>{
    res.render("login.ejs")
})



App.listen(PORT,()=>{
    console.log(`The Server is Up and Running on ${PORT}`)
})